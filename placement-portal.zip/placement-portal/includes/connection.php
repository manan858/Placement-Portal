<?php

$db = mysqli_connect('localhost', 'root', '', 'dbms_placement') or die(mysql_error());
